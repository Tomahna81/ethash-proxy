# Ethash-mining-stratum-proxy
Scavanging of Ethash-mining-pool to make a stratum proxy for Ethash based coins


** v0.1 : First Operational version **
   * Code tested on ethermine pool and working well
   * Issues: Still requires some code cleaning (removing all unecessary code related to payouts)
   * The API side need to be tested and adjusted